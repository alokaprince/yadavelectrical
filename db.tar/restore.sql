--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 14.12 (Ubuntu 14.12-0ubuntu0.22.04.1)
-- Dumped by pg_dump version 14.12 (Ubuntu 14.12-0ubuntu0.22.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE yadavelectricals;
--
-- Name: yadavelectricals; Type: DATABASE; Schema: -; Owner: ubuntu
--

CREATE DATABASE yadavelectricals WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'C.UTF-8';


ALTER DATABASE yadavelectricals OWNER TO ubuntu;

\connect yadavelectricals

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: ar_internal_metadata; Type: TABLE; Schema: public; Owner: ubuntu
--

CREATE TABLE public.ar_internal_metadata (
    key character varying NOT NULL,
    value character varying,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL
);


ALTER TABLE public.ar_internal_metadata OWNER TO ubuntu;

--
-- Name: bills; Type: TABLE; Schema: public; Owner: ubuntu
--

CREATE TABLE public.bills (
    id bigint NOT NULL,
    billno character varying,
    date date,
    credit double precision,
    debit double precision,
    remark text,
    customer_id bigint NOT NULL,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL
);


ALTER TABLE public.bills OWNER TO ubuntu;

--
-- Name: bills_id_seq; Type: SEQUENCE; Schema: public; Owner: ubuntu
--

CREATE SEQUENCE public.bills_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.bills_id_seq OWNER TO ubuntu;

--
-- Name: bills_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ubuntu
--

ALTER SEQUENCE public.bills_id_seq OWNED BY public.bills.id;


--
-- Name: customers; Type: TABLE; Schema: public; Owner: ubuntu
--

CREATE TABLE public.customers (
    id bigint NOT NULL,
    name character varying,
    father character varying,
    address character varying,
    mobile character varying,
    total double precision,
    recieve double precision,
    balance double precision,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL,
    block character varying
);


ALTER TABLE public.customers OWNER TO ubuntu;

--
-- Name: customers_id_seq; Type: SEQUENCE; Schema: public; Owner: ubuntu
--

CREATE SEQUENCE public.customers_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.customers_id_seq OWNER TO ubuntu;

--
-- Name: customers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ubuntu
--

ALTER SEQUENCE public.customers_id_seq OWNED BY public.customers.id;


--
-- Name: dailyexps; Type: TABLE; Schema: public; Owner: ubuntu
--

CREATE TABLE public.dailyexps (
    id bigint NOT NULL,
    name character varying,
    remark text,
    amount double precision,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL,
    amount2 double precision
);


ALTER TABLE public.dailyexps OWNER TO ubuntu;

--
-- Name: dailyexps_id_seq; Type: SEQUENCE; Schema: public; Owner: ubuntu
--

CREATE SEQUENCE public.dailyexps_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.dailyexps_id_seq OWNER TO ubuntu;

--
-- Name: dailyexps_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ubuntu
--

ALTER SEQUENCE public.dailyexps_id_seq OWNED BY public.dailyexps.id;


--
-- Name: dealerbills; Type: TABLE; Schema: public; Owner: ubuntu
--

CREATE TABLE public.dealerbills (
    id bigint NOT NULL,
    billno character varying,
    date date,
    credit double precision,
    debit double precision,
    remark text,
    dealer_id bigint NOT NULL,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL
);


ALTER TABLE public.dealerbills OWNER TO ubuntu;

--
-- Name: dealerbills_id_seq; Type: SEQUENCE; Schema: public; Owner: ubuntu
--

CREATE SEQUENCE public.dealerbills_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.dealerbills_id_seq OWNER TO ubuntu;

--
-- Name: dealerbills_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ubuntu
--

ALTER SEQUENCE public.dealerbills_id_seq OWNED BY public.dealerbills.id;


--
-- Name: dealeritems; Type: TABLE; Schema: public; Owner: ubuntu
--

CREATE TABLE public.dealeritems (
    id bigint NOT NULL,
    itemname character varying,
    quantity double precision,
    rate double precision,
    unit character varying,
    amount double precision,
    dealerbill_id bigint NOT NULL,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL
);


ALTER TABLE public.dealeritems OWNER TO ubuntu;

--
-- Name: dealeritems_id_seq; Type: SEQUENCE; Schema: public; Owner: ubuntu
--

CREATE SEQUENCE public.dealeritems_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.dealeritems_id_seq OWNER TO ubuntu;

--
-- Name: dealeritems_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ubuntu
--

ALTER SEQUENCE public.dealeritems_id_seq OWNED BY public.dealeritems.id;


--
-- Name: dealers; Type: TABLE; Schema: public; Owner: ubuntu
--

CREATE TABLE public.dealers (
    id bigint NOT NULL,
    name character varying,
    address character varying,
    mobile character varying,
    total double precision,
    recieve double precision,
    balance double precision,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL,
    block character varying
);


ALTER TABLE public.dealers OWNER TO ubuntu;

--
-- Name: dealers_id_seq; Type: SEQUENCE; Schema: public; Owner: ubuntu
--

CREATE SEQUENCE public.dealers_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.dealers_id_seq OWNER TO ubuntu;

--
-- Name: dealers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ubuntu
--

ALTER SEQUENCE public.dealers_id_seq OWNED BY public.dealers.id;


--
-- Name: items; Type: TABLE; Schema: public; Owner: ubuntu
--

CREATE TABLE public.items (
    id bigint NOT NULL,
    itemname character varying,
    quantity double precision,
    rate double precision,
    unit character varying,
    amount double precision,
    bill_id bigint NOT NULL,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL
);


ALTER TABLE public.items OWNER TO ubuntu;

--
-- Name: items_id_seq; Type: SEQUENCE; Schema: public; Owner: ubuntu
--

CREATE SEQUENCE public.items_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.items_id_seq OWNER TO ubuntu;

--
-- Name: items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ubuntu
--

ALTER SEQUENCE public.items_id_seq OWNED BY public.items.id;


--
-- Name: schema_migrations; Type: TABLE; Schema: public; Owner: ubuntu
--

CREATE TABLE public.schema_migrations (
    version character varying NOT NULL
);


ALTER TABLE public.schema_migrations OWNER TO ubuntu;

--
-- Name: stocks; Type: TABLE; Schema: public; Owner: ubuntu
--

CREATE TABLE public.stocks (
    id bigint NOT NULL,
    prodname character varying,
    prodno character varying,
    manufact character varying,
    category character varying,
    unit character varying,
    quantity double precision,
    price1 double precision,
    price2 double precision,
    price3 double precision,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL
);


ALTER TABLE public.stocks OWNER TO ubuntu;

--
-- Name: stocks_id_seq; Type: SEQUENCE; Schema: public; Owner: ubuntu
--

CREATE SEQUENCE public.stocks_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.stocks_id_seq OWNER TO ubuntu;

--
-- Name: stocks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ubuntu
--

ALTER SEQUENCE public.stocks_id_seq OWNED BY public.stocks.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: ubuntu
--

CREATE TABLE public.users (
    id bigint NOT NULL,
    email character varying DEFAULT ''::character varying NOT NULL,
    encrypted_password character varying DEFAULT ''::character varying NOT NULL,
    reset_password_token character varying,
    reset_password_sent_at timestamp without time zone,
    remember_created_at timestamp without time zone,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL
);


ALTER TABLE public.users OWNER TO ubuntu;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: ubuntu
--

CREATE SEQUENCE public.users_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_id_seq OWNER TO ubuntu;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ubuntu
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: works; Type: TABLE; Schema: public; Owner: ubuntu
--

CREATE TABLE public.works (
    id bigint NOT NULL,
    name character varying,
    "HP" character varying,
    company character varying,
    model character varying,
    pitch1 character varying,
    turn1 double precision,
    gauge double precision,
    weight double precision,
    slot integer,
    connection character varying,
    coil character varying,
    pitch2 character varying,
    turn2 double precision,
    stetarlen double precision,
    length double precision,
    remark text,
    amount double precision,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL,
    amount2 double precision,
    guage2 double precision,
    mobile character varying,
    date character varying
);


ALTER TABLE public.works OWNER TO ubuntu;

--
-- Name: works_id_seq; Type: SEQUENCE; Schema: public; Owner: ubuntu
--

CREATE SEQUENCE public.works_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.works_id_seq OWNER TO ubuntu;

--
-- Name: works_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ubuntu
--

ALTER SEQUENCE public.works_id_seq OWNED BY public.works.id;


--
-- Name: bills id; Type: DEFAULT; Schema: public; Owner: ubuntu
--

ALTER TABLE ONLY public.bills ALTER COLUMN id SET DEFAULT nextval('public.bills_id_seq'::regclass);


--
-- Name: customers id; Type: DEFAULT; Schema: public; Owner: ubuntu
--

ALTER TABLE ONLY public.customers ALTER COLUMN id SET DEFAULT nextval('public.customers_id_seq'::regclass);


--
-- Name: dailyexps id; Type: DEFAULT; Schema: public; Owner: ubuntu
--

ALTER TABLE ONLY public.dailyexps ALTER COLUMN id SET DEFAULT nextval('public.dailyexps_id_seq'::regclass);


--
-- Name: dealerbills id; Type: DEFAULT; Schema: public; Owner: ubuntu
--

ALTER TABLE ONLY public.dealerbills ALTER COLUMN id SET DEFAULT nextval('public.dealerbills_id_seq'::regclass);


--
-- Name: dealeritems id; Type: DEFAULT; Schema: public; Owner: ubuntu
--

ALTER TABLE ONLY public.dealeritems ALTER COLUMN id SET DEFAULT nextval('public.dealeritems_id_seq'::regclass);


--
-- Name: dealers id; Type: DEFAULT; Schema: public; Owner: ubuntu
--

ALTER TABLE ONLY public.dealers ALTER COLUMN id SET DEFAULT nextval('public.dealers_id_seq'::regclass);


--
-- Name: items id; Type: DEFAULT; Schema: public; Owner: ubuntu
--

ALTER TABLE ONLY public.items ALTER COLUMN id SET DEFAULT nextval('public.items_id_seq'::regclass);


--
-- Name: stocks id; Type: DEFAULT; Schema: public; Owner: ubuntu
--

ALTER TABLE ONLY public.stocks ALTER COLUMN id SET DEFAULT nextval('public.stocks_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: ubuntu
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Name: works id; Type: DEFAULT; Schema: public; Owner: ubuntu
--

ALTER TABLE ONLY public.works ALTER COLUMN id SET DEFAULT nextval('public.works_id_seq'::regclass);


--
-- Data for Name: ar_internal_metadata; Type: TABLE DATA; Schema: public; Owner: ubuntu
--

COPY public.ar_internal_metadata (key, value, created_at, updated_at) FROM stdin;
\.
COPY public.ar_internal_metadata (key, value, created_at, updated_at) FROM '$$PATH$$/3409.dat';

--
-- Data for Name: bills; Type: TABLE DATA; Schema: public; Owner: ubuntu
--

COPY public.bills (id, billno, date, credit, debit, remark, customer_id, created_at, updated_at) FROM stdin;
\.
COPY public.bills (id, billno, date, credit, debit, remark, customer_id, created_at, updated_at) FROM '$$PATH$$/3410.dat';

--
-- Data for Name: customers; Type: TABLE DATA; Schema: public; Owner: ubuntu
--

COPY public.customers (id, name, father, address, mobile, total, recieve, balance, created_at, updated_at, block) FROM stdin;
\.
COPY public.customers (id, name, father, address, mobile, total, recieve, balance, created_at, updated_at, block) FROM '$$PATH$$/3412.dat';

--
-- Data for Name: dailyexps; Type: TABLE DATA; Schema: public; Owner: ubuntu
--

COPY public.dailyexps (id, name, remark, amount, created_at, updated_at, amount2) FROM stdin;
\.
COPY public.dailyexps (id, name, remark, amount, created_at, updated_at, amount2) FROM '$$PATH$$/3414.dat';

--
-- Data for Name: dealerbills; Type: TABLE DATA; Schema: public; Owner: ubuntu
--

COPY public.dealerbills (id, billno, date, credit, debit, remark, dealer_id, created_at, updated_at) FROM stdin;
\.
COPY public.dealerbills (id, billno, date, credit, debit, remark, dealer_id, created_at, updated_at) FROM '$$PATH$$/3416.dat';

--
-- Data for Name: dealeritems; Type: TABLE DATA; Schema: public; Owner: ubuntu
--

COPY public.dealeritems (id, itemname, quantity, rate, unit, amount, dealerbill_id, created_at, updated_at) FROM stdin;
\.
COPY public.dealeritems (id, itemname, quantity, rate, unit, amount, dealerbill_id, created_at, updated_at) FROM '$$PATH$$/3418.dat';

--
-- Data for Name: dealers; Type: TABLE DATA; Schema: public; Owner: ubuntu
--

COPY public.dealers (id, name, address, mobile, total, recieve, balance, created_at, updated_at, block) FROM stdin;
\.
COPY public.dealers (id, name, address, mobile, total, recieve, balance, created_at, updated_at, block) FROM '$$PATH$$/3420.dat';

--
-- Data for Name: items; Type: TABLE DATA; Schema: public; Owner: ubuntu
--

COPY public.items (id, itemname, quantity, rate, unit, amount, bill_id, created_at, updated_at) FROM stdin;
\.
COPY public.items (id, itemname, quantity, rate, unit, amount, bill_id, created_at, updated_at) FROM '$$PATH$$/3422.dat';

--
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: public; Owner: ubuntu
--

COPY public.schema_migrations (version) FROM stdin;
\.
COPY public.schema_migrations (version) FROM '$$PATH$$/3424.dat';

--
-- Data for Name: stocks; Type: TABLE DATA; Schema: public; Owner: ubuntu
--

COPY public.stocks (id, prodname, prodno, manufact, category, unit, quantity, price1, price2, price3, created_at, updated_at) FROM stdin;
\.
COPY public.stocks (id, prodname, prodno, manufact, category, unit, quantity, price1, price2, price3, created_at, updated_at) FROM '$$PATH$$/3425.dat';

--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: ubuntu
--

COPY public.users (id, email, encrypted_password, reset_password_token, reset_password_sent_at, remember_created_at, created_at, updated_at) FROM stdin;
\.
COPY public.users (id, email, encrypted_password, reset_password_token, reset_password_sent_at, remember_created_at, created_at, updated_at) FROM '$$PATH$$/3427.dat';

--
-- Data for Name: works; Type: TABLE DATA; Schema: public; Owner: ubuntu
--

COPY public.works (id, name, "HP", company, model, pitch1, turn1, gauge, weight, slot, connection, coil, pitch2, turn2, stetarlen, length, remark, amount, created_at, updated_at, amount2, guage2, mobile, date) FROM stdin;
\.
COPY public.works (id, name, "HP", company, model, pitch1, turn1, gauge, weight, slot, connection, coil, pitch2, turn2, stetarlen, length, remark, amount, created_at, updated_at, amount2, guage2, mobile, date) FROM '$$PATH$$/3429.dat';

--
-- Name: bills_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ubuntu
--

SELECT pg_catalog.setval('public.bills_id_seq', 861, true);


--
-- Name: customers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ubuntu
--

SELECT pg_catalog.setval('public.customers_id_seq', 601, true);


--
-- Name: dailyexps_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ubuntu
--

SELECT pg_catalog.setval('public.dailyexps_id_seq', 72, true);


--
-- Name: dealerbills_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ubuntu
--

SELECT pg_catalog.setval('public.dealerbills_id_seq', 245, true);


--
-- Name: dealeritems_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ubuntu
--

SELECT pg_catalog.setval('public.dealeritems_id_seq', 1, true);


--
-- Name: dealers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ubuntu
--

SELECT pg_catalog.setval('public.dealers_id_seq', 79, true);


--
-- Name: items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ubuntu
--

SELECT pg_catalog.setval('public.items_id_seq', 1393, true);


--
-- Name: stocks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ubuntu
--

SELECT pg_catalog.setval('public.stocks_id_seq', 50, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ubuntu
--

SELECT pg_catalog.setval('public.users_id_seq', 4, true);


--
-- Name: works_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ubuntu
--

SELECT pg_catalog.setval('public.works_id_seq', 438, true);


--
-- Name: ar_internal_metadata ar_internal_metadata_pkey; Type: CONSTRAINT; Schema: public; Owner: ubuntu
--

ALTER TABLE ONLY public.ar_internal_metadata
    ADD CONSTRAINT ar_internal_metadata_pkey PRIMARY KEY (key);


--
-- Name: bills bills_pkey; Type: CONSTRAINT; Schema: public; Owner: ubuntu
--

ALTER TABLE ONLY public.bills
    ADD CONSTRAINT bills_pkey PRIMARY KEY (id);


--
-- Name: customers customers_pkey; Type: CONSTRAINT; Schema: public; Owner: ubuntu
--

ALTER TABLE ONLY public.customers
    ADD CONSTRAINT customers_pkey PRIMARY KEY (id);


--
-- Name: dailyexps dailyexps_pkey; Type: CONSTRAINT; Schema: public; Owner: ubuntu
--

ALTER TABLE ONLY public.dailyexps
    ADD CONSTRAINT dailyexps_pkey PRIMARY KEY (id);


--
-- Name: dealerbills dealerbills_pkey; Type: CONSTRAINT; Schema: public; Owner: ubuntu
--

ALTER TABLE ONLY public.dealerbills
    ADD CONSTRAINT dealerbills_pkey PRIMARY KEY (id);


--
-- Name: dealeritems dealeritems_pkey; Type: CONSTRAINT; Schema: public; Owner: ubuntu
--

ALTER TABLE ONLY public.dealeritems
    ADD CONSTRAINT dealeritems_pkey PRIMARY KEY (id);


--
-- Name: dealers dealers_pkey; Type: CONSTRAINT; Schema: public; Owner: ubuntu
--

ALTER TABLE ONLY public.dealers
    ADD CONSTRAINT dealers_pkey PRIMARY KEY (id);


--
-- Name: items items_pkey; Type: CONSTRAINT; Schema: public; Owner: ubuntu
--

ALTER TABLE ONLY public.items
    ADD CONSTRAINT items_pkey PRIMARY KEY (id);


--
-- Name: schema_migrations schema_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: ubuntu
--

ALTER TABLE ONLY public.schema_migrations
    ADD CONSTRAINT schema_migrations_pkey PRIMARY KEY (version);


--
-- Name: stocks stocks_pkey; Type: CONSTRAINT; Schema: public; Owner: ubuntu
--

ALTER TABLE ONLY public.stocks
    ADD CONSTRAINT stocks_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: ubuntu
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: works works_pkey; Type: CONSTRAINT; Schema: public; Owner: ubuntu
--

ALTER TABLE ONLY public.works
    ADD CONSTRAINT works_pkey PRIMARY KEY (id);


--
-- Name: index_bills_on_customer_id; Type: INDEX; Schema: public; Owner: ubuntu
--

CREATE INDEX index_bills_on_customer_id ON public.bills USING btree (customer_id);


--
-- Name: index_dealerbills_on_dealer_id; Type: INDEX; Schema: public; Owner: ubuntu
--

CREATE INDEX index_dealerbills_on_dealer_id ON public.dealerbills USING btree (dealer_id);


--
-- Name: index_dealeritems_on_dealerbill_id; Type: INDEX; Schema: public; Owner: ubuntu
--

CREATE INDEX index_dealeritems_on_dealerbill_id ON public.dealeritems USING btree (dealerbill_id);


--
-- Name: index_items_on_bill_id; Type: INDEX; Schema: public; Owner: ubuntu
--

CREATE INDEX index_items_on_bill_id ON public.items USING btree (bill_id);


--
-- Name: index_users_on_email; Type: INDEX; Schema: public; Owner: ubuntu
--

CREATE UNIQUE INDEX index_users_on_email ON public.users USING btree (email);


--
-- Name: index_users_on_reset_password_token; Type: INDEX; Schema: public; Owner: ubuntu
--

CREATE UNIQUE INDEX index_users_on_reset_password_token ON public.users USING btree (reset_password_token);


--
-- Name: dealeritems fk_rails_6fc584a779; Type: FK CONSTRAINT; Schema: public; Owner: ubuntu
--

ALTER TABLE ONLY public.dealeritems
    ADD CONSTRAINT fk_rails_6fc584a779 FOREIGN KEY (dealerbill_id) REFERENCES public.dealerbills(id);


--
-- Name: dealerbills fk_rails_73058b5424; Type: FK CONSTRAINT; Schema: public; Owner: ubuntu
--

ALTER TABLE ONLY public.dealerbills
    ADD CONSTRAINT fk_rails_73058b5424 FOREIGN KEY (dealer_id) REFERENCES public.dealers(id);


--
-- Name: items fk_rails_79052aeaa1; Type: FK CONSTRAINT; Schema: public; Owner: ubuntu
--

ALTER TABLE ONLY public.items
    ADD CONSTRAINT fk_rails_79052aeaa1 FOREIGN KEY (bill_id) REFERENCES public.bills(id);


--
-- Name: bills fk_rails_eddd950160; Type: FK CONSTRAINT; Schema: public; Owner: ubuntu
--

ALTER TABLE ONLY public.bills
    ADD CONSTRAINT fk_rails_eddd950160 FOREIGN KEY (customer_id) REFERENCES public.customers(id);


--
-- PostgreSQL database dump complete
--

